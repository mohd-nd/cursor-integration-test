namespace CursorSubmissionApp.Models;

public record CursorAgentResponse(bool Success, string Message);
